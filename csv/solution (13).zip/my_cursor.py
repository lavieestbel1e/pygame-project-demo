import pygame

class GameOverSprite(pygame.sprite.Sprite):
    def __init__(self, x, filename):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(filename).convert_alpha()
        self.rect = self.image.get_rect(center=(x, 150))

    def move(self, direction):
        self.direction = direction
        if self.direction == 'UP':
            self.rect.y -= 10
        elif self.direction == 'DOWN':
            self.rect.y += 10
        elif self.direction == 'RIGHT':
            self.rect.x += 10
        elif self.direction == 'LEFT':
            self.rect.x -= 10

pygame.init()

size = width, height = 300, 300
screen = pygame.display.set_mode(size)
pygame.display.set_caption('Герой двигается!')
clock = pygame.time.Clock()
fps = 30

speed = 6

gs = GameOverSprite(150, 'data/creature.png')


running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                gs.move('UP')
            elif event.key == pygame.K_DOWN:
                gs.move('DOWN')
            elif event.key == pygame.K_RIGHT:
                gs.move('RIGHT')
            elif event.key == pygame.K_LEFT:
                gs.move('LEFT')
    screen.fill('white')
    screen.blit(gs.image, gs.rect)
    clock.tick(fps)


    pygame.display.flip()
pygame.quit()
